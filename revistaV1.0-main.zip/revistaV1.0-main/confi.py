Bot_token = "5935019057:AAGC8UersIuBWo2cNvYMgXHnULdO1vT-rt8"
chanel_id =  -1001910694479
db_access = 2 #value int de la db, desmarcar line 1531 bot.py